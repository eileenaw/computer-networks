import socket
import struct
import random

IP_POOL = ["192.168.1.{}".format(i) for i in range(2, 255)]
ASSIGNED_IPS = {}

def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_socket.bind(('0.0.0.0', 67))
    print("DHCP Server is listening on port 67")
    while True:
        data, address = server_socket.recvfrom(1024)
        dhcp_message = struct.unpack('!BBBBI', data[:8])
        message_type = dhcp_message[0]
        if message_type == 1:  # DHCP Discover
            xid = dhcp_message[4]
            offered_ip = random.choice([ip for ip in IP_POOL if ip not in ASSIGNED_IPS.values()])
            OFFER = struct.pack('!BBBBI', 2, 1, 6, 0, xid) + socket.inet_aton(offered_ip)
            server_socket.sendto(OFFER, address)
        elif message_type == 3:  # DHCP Request
            xid = dhcp_message[4]
            requested_ip = socket.inet_ntoa(data[8:12])
            if requested_ip in IP_POOL:
                ASSIGNED_IPS[address[0]] = requested_ip
                ACK = struct.pack('!BBBBI', 5, 1, 6, 0, xid) + socket.inet_aton(requested_ip)
                server_socket.sendto(ACK, address)

if __name__ == "__main__":
    main()
