import socket
import struct

def main():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    client_socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    xid = random.randint(1, 1000)
    DISCOVER = struct.pack('!BBBBI', 1, 1, 6, 0, xid)
    client_socket.sendto(DISCOVER, ('<broadcast>', 67))
    data, _ = client_socket.recvfrom(1024)
    OFFER = struct.unpack('!BBBBI', data[:8])
    offered_ip = socket.inet_ntoa(data[8:12])
    REQUEST = struct.pack('!BBBBI', 3, 1, 6, 0, xid) + socket.inet_aton(offered_ip)
    client_socket.sendto(REQUEST, ('<broadcast>', 67))
    data, _ = client_socket.recvfrom(1024)
    ACK = struct.unpack('!BBBBI', data[:8])
    assigned_ip = socket.inet_ntoa(data[8:12])
    print(f"Assigned IP: {assigned_ip}")
    client_socket.close()

if __name__ == "__main__":
    main()
