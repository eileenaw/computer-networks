import socket

def main():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(('localhost', 12345))
    command = input("Enter command to execute: ")
    client_socket.send(command.encode())
    output = client_socket.recv(4096).decode()
    print("Command output:\n", output)
    client_socket.close()

if __name__ == "__main__":
    main()
