import ftplib

def upload_file():
    ftp = ftplib.FTP("localhost")
    ftp.login("user", "12345")
    filename = "example.txt"
    with open(filename, "rb") as file:
        ftp.storbinary(f"STOR {filename}", file)
    ftp.quit()

if __name__ == "__main__":
    upload_file()
