import socket
import time
import random

def get_currency_prices():
    yen = random.uniform(100, 120) 
    dollar = random.uniform(1, 2) 
    euro = random.uniform(0.8, 1.5)  
    return f"Yen: {yen:.2f}, Dollar: {dollar:.2f}, Euro: {euro:.2f}"
def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('0.0.0.0', 12345))
    server_socket.listen(5)
    print("Server is listening on port 12345")
    while True:
        client_socket, client_address = server_socket.accept()
        print(f"Connection from {client_address} has been established.")
        while True:
            prices = get_currency_prices()
            client_socket.send(prices.encode())
            time.sleep(5)  
            try:
                ack = client_socket.recv(1024).decode()
                if ack.lower() == 'exit':
                    break
            except socket.error:
                break
        client_socket.close()

if __name__ == "__main__":
    main()
