import socket
import time

def main():
    server_ip = input("Enter server IP address: ")
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((server_ip, 12345))
    while True:
        request = "Hello, Server!"
        client_socket.send(request.encode())
        response = client_socket.recv(1024).decode()
        print("Server response:", response)
        time.sleep(1)

if __name__ == "__main__":
    main()
