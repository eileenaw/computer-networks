import socket
import threading
import time

MAX_REQUESTS = 100 
TIME_WINDOW = 10
request_log = {}

def handle_client(client_socket, client_address):
    while True:
        request = client_socket.recv(1024).decode()
        if not request:
            break
        current_time = time.time()
        client_log = request_log.get(client_address[0], [])
        client_log = [t for t in client_log if current_time - t < TIME_WINDOW]
        client_log.append(current_time)
        request_log[client_address[0]] = client_log
        if len(client_log) > MAX_REQUESTS:
            print(f"DDOS attack detected from {client_address[0]}. Connection closed.")
            client_socket.close()
            return
        response = "Request received."
        client_socket.send(response.encode())
    client_socket.close()

def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('0.0.0.0', 12345))
    server_socket.listen(5)
    print("Server is listening on port 12345")
    while True:
        client_socket, client_address = server_socket.accept()
        print(f"Connection from {client_address} has been established.")
        client_handler = threading.Thread(target=handle_client, args=(client_socket, client_address))
        client_handler.start()

if __name__ == "__main__":
    main()
