import socket

def main():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(('localhost', 12345))
    command = input("Enter command (GET/SET key value): ")
    client_socket.send(command.encode())
    response = client_socket.recv(1024).decode()
    print("Server response:", response)
    client_socket.close()

if __name__ == "__main__":
    main()
