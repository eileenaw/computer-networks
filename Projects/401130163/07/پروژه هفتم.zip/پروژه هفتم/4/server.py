import socket
import json

def load_data(filename):
    try:
        with open(filename, 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        return {}

def save_data(filename, data):
    with open(filename, 'w') as file:
        json.dump(data, file)

def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('0.0.0.0', 12345))
    server_socket.listen(5)
    print("Server is listening on port 12345")
    data = load_data('data.json')
    while True:
        client_socket, client_address = server_socket.accept()
        print(f"Connection from {client_address} has been established.")
        request = client_socket.recv(1024).decode()
        command, key, value = request.split(' ', 2)
        if command.lower() == 'get':
            response = data.get(key, 'Key not found.')
        elif command.lower() == 'set':
            data[key] = value
            save_data('data.json', data)
            response = 'Key-Value pair set.'
        else:
            response = 'Invalid command.'
        client_socket.send(response.encode())
        client_socket.close()

if __name__ == "__main__":
    main()
