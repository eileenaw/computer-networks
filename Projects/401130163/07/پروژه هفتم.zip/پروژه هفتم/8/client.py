import socket

def main():
    server_ip = input("Enter DNS server IP address: ")
    domain = input("Enter domain to resolve: ")
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    client_socket.sendto(domain.encode(), (server_ip, 5353))
    data, _ = client_socket.recvfrom(1024)
    ip_address = data.decode()
    print(f"IP address for {domain}: {ip_address}")
    client_socket.close()

if __name__ == "__main__":
    main()
