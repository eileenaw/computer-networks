import socket

dns_records = {
    "google.com": "142.250.74.78",
    "facebook.com": "69.63.176.13",
    "youtube.com": "172.217.10.14",
    "yahoo.com": "74.6.231.21",
    "wikipedia.org": "208.80.154.224",
    "amazon.com": "205.251.242.103",
    "twitter.com": "104.244.42.65",
    "instagram.com": "52.5.102.156",
    "linkedin.com": "108.174.10.10",
    "netflix.com": "45.57.72.20"
}

def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_socket.bind(('0.0.0.0', 5353))
    print("DNS Server is listening on port 5353")
    while True:
        data, client_address = server_socket.recvfrom(1024)
        domain = data.decode().strip()
        ip_address = dns_records.get(domain, "Domain not found.")
        server_socket.sendto(ip_address.encode(), client_address)

if __name__ == "__main__":
    main()
