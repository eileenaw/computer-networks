import socket

def main():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(('localhost', 12345))
    while True:
        message = client_socket.recv(1024).decode()
        print(message)
        if "wins" in message or "tie" in message:
            break
        if message == "Your turn":
            move = input("Enter your move (0-8): ")
            client_socket.send(move.encode())
    client_socket.close()

if __name__ == "__main__":
    main()
