import socket
import threading
import queue

clients_queue = queue.Queue()
board = [" " for _ in range(9)]
current_player = 0

def print_board():
    print(f"{board[0]} | {board[1]} | {board[2]}")
    print("--+---+--")
    print(f"{board[3]} | {board[4]} | {board[5]}")
    print("--+---+--")
    print(f"{board[6]} | {board[7]} | {board[8]}")

def check_winner():
    win_positions = [(0, 1, 2), (3, 4, 5), (6, 7, 8),
                     (0, 3, 6), (1, 4, 7), (2, 5, 8),
                     (0, 4, 8), (2, 4, 6)]
    for pos in win_positions:
        if board[pos[0]] == board[pos[1]] == board[pos[2]] and board[pos[0]] != " ":
            return board[pos[0]]
    return None

def handle_client(client_socket, player):
    global current_player
    while True:
        if current_player == player:
            client_socket.send("Your turn".encode())
            move = int(client_socket.recv(1024).decode())
            if board[move] == " ":
                board[move] = "X" if player == 0 else "O"
                current_player = 1 - current_player
                winner = check_winner()
                if winner:
                    client_socket.send(f"Player {winner} wins!".encode())
                    break
                elif " " not in board:
                    client_socket.send("It's a tie!".encode())
                    break
            print_board()
        else:
            client_socket.send("Wait for your turn".encode())
    client_socket.close()

def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('0.0.0.0', 12345))
    server_socket.listen(5)
    print("Server is listening on port 12345")
    while True:
        client_socket, client_address = server_socket.accept()
        print(f"Connection from {client_address} has been established.")
        clients_queue.put(client_socket)
        if clients_queue.qsize() >= 2:
            player1 = clients_queue.get()
            player2 = clients_queue.get()
            threading.Thread(target=handle_client, args=(player1, 0)).start()
            threading.Thread(target=handle_client, args=(player2, 1)).start()

if __name__ == "__main__":
    main()
