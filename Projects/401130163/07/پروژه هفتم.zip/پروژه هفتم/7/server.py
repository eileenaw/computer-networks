import socket
import ssl
import threading

HOST = '0.0.0.0'
PORT = 12345

def handle_client(conn, addr):
    print(f"Connected by {addr}")
    try:
        while True:
            data = conn.recv(1024)
            if not data:
                break
            print(f"Received from {addr}: {data.decode()}")
            conn.sendall(data)
    finally:
        conn.close()

def main():
    context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
    context.load_cert_chain(certfile="server.pem", keyfile="server-key.pem")
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        server_socket.bind((HOST, PORT))
        server_socket.listen(5)
        print(f"Server is listening on port {PORT}")
        with context.wrap_socket(server_socket, server_side=True) as ssock:
            while True:
                conn, addr = ssock.accept()
                threading.Thread(target=handle_client, args=(conn, addr)).start()

if __name__ == "__main__":
    main()
