import socket
import ssl

HOST = 'localhost'
PORT = 12345

def main():
    context = ssl.create_default_context()
    context.load_verify_locations(cafile="server.pem")
    with socket.create_connection((HOST, PORT)) as client_socket:
        with context.wrap_socket(client_socket, server_hostname=HOST) as ssock:
            while True:
                message = input("Enter message: ")
                if message.lower() == 'exit':
                    break
                ssock.sendall(message.encode())
                data = ssock.recv(1024)
                print(f"Received: {data.decode()}")

if __name__ == "__main__":
    main()
